'use strict';

const Homey = require('homey');

class SolarControllerApp extends Homey.App {

  async onInit() {
    this.log('Solar Controller app started (v0.7.73)');

    // Conditions and actions include a Device argument; triggers are device triggers.
    const condPowerAbove = this.homey.flow.getConditionCard('power_above');
    const condPwmAbove = this.homey.flow.getConditionCard('pwm_above');
    const condTempAbove = this.homey.flow.getConditionCard('temp_above');
    const condLegActive = this.homey.flow.getConditionCard('legionella_is_active');

    const condAdviceIs = this.homey.flow.getConditionCard('advice_is');
    const condElecBelow = this.homey.flow.getConditionCard('elec_price_below');
    const condGasBelow = this.homey.flow.getConditionCard('gas_price_below');
    const condSunScheduleIs = this.homey.flow.getConditionCard('sun_schedule_is');
    const condControlModeIs = this.homey.flow.getConditionCard('control_mode_is');
    const condMcRoleIs = this.homey.flow.getConditionCard('mc_role_is');
    const condMcFallbackActive = this.homey.flow.getConditionCard('mc_fallback_is_active');
    const condRelayOn = this.homey.flow.getConditionCard('relay_is_on');
    const condTempGateBlocked = this.homey.flow.getConditionCard('temp_gate_is_blocked');

    const actForceOn = this.homey.flow.getActionCard('force_heat_on');
    const actForceOff = this.homey.flow.getActionCard('force_heat_off');
    const actSetPwm = this.homey.flow.getActionCard('set_pwm_percent');
    const actSetMaxOut = this.homey.flow.getActionCard('set_max_output_pct');
    const actSetSunSchedule = this.homey.flow.getActionCard('set_sun_schedule_mode');
    const actRelayOn = this.homey.flow.getActionCard('relay_on');
    const actRelayOff = this.homey.flow.getActionCard('relay_off');
    const actLegionellaRunNow = this.homey.flow.getActionCard('legionella_run_now');
    const actLegionellaCancel = this.homey.flow.getActionCard('legionella_cancel');

    // Conditions: read current capability values from the selected device
    condPowerAbove.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const power = Number(args.device.getCapabilityValue('measure_power'));
      if (!Number.isFinite(threshold) || !Number.isFinite(power)) return false;
      return power > threshold;
    });

    condPwmAbove.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const pwmPercent = Number(args.device.getCapabilityValue('sc_pwm'));
      if (!Number.isFinite(threshold) || !Number.isFinite(pwmPercent)) return false;
      return pwmPercent > threshold;
    });

    condTempAbove.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const temperature = Number(args.device.getCapabilityValue('measure_temperature'));
      if (!Number.isFinite(threshold) || !Number.isFinite(temperature)) return false;
      return temperature > threshold;
    });

    // Condition: Legionella active
    condLegActive.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const v = args.device.getCapabilityValue('sc_legionella_active');
      return v === 'on' || v === true || v === 1;
    });

    // Condition: Heating advice equals selected option
    condAdviceIs.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const want = String(args.advice || 'unknown');
      const cur = String(args.device.getCapabilityValue('sc_advice') || 'unknown');
      return cur === want;
    });

    // Condition: Electricity price below threshold (€/kWh)
    condElecBelow.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const v = Number(args.device.getCapabilityValue('sc_elec_price_now'));
      if (!Number.isFinite(threshold) || !Number.isFinite(v)) return false;
      return v < threshold;
    });

    // Condition: Gas price below threshold (€/m³)
    condGasBelow.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const v = Number(args.device.getCapabilityValue('sc_gas_price_today'));
      if (!Number.isFinite(threshold) || !Number.isFinite(v)) return false;
      return v < threshold;
    });

    condSunScheduleIs.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return String(args.device.getCapabilityValue('sc_sun_mode') || 'unknown') === String(args.mode || 'unknown');
    });

    condControlModeIs.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const raw = String(args.device.getStoreValue('control_mode_raw') || '').toUpperCase();
      return raw === String(args.mode || '').toUpperCase();
    });

    condMcRoleIs.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return String(args.device.getCapabilityValue('sc_mc_role') || 'unknown') === String(args.role || 'unknown');
    });

    condMcFallbackActive.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device.getCapabilityValue('sc_mc_fallback_active') === true;
    });

    condRelayOn.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device.getCapabilityValue('sc_relay_manual_on') === true;
    });

    condTempGateBlocked.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device.getCapabilityValue('sc_temp_gate_blocked') === true;
    });


    // Actions: call device helpers (POST to controller)
    actForceOn.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowForceHeat(true);
    });

    actForceOff.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowForceHeat(false);
    });

    actSetPwm.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const percent = Number(args.percent);
      if (!Number.isFinite(percent)) throw new Error('Invalid PWM percent');
      return args.device._flowSetPwm(percent);
    });

    actSetMaxOut.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const percent = Number(args.percent);
      if (!Number.isFinite(percent)) throw new Error('Invalid max output percent');
      return args.device._flowSetMaxOutPct(percent);
    });

    actSetSunSchedule.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowSetSunScheduleMode(args.mode);
    });

    actRelayOn.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowRelay(true);
    });

    actRelayOff.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowRelay(false);
    });

    actLegionellaRunNow.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowLegionellaRunNow();
    });

    actLegionellaCancel.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowLegionellaCancel();
    });
  }

}

module.exports = SolarControllerApp;
