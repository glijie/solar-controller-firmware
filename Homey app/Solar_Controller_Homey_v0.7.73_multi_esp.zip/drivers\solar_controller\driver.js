'use strict';
const Homey = require('homey');

function createPairingId() {
  const rand = Math.random().toString(36).slice(2, 10);
  return `solar_controller_${Date.now().toString(36)}_${rand}`;
}

class SolarControllerDriver extends Homey.Driver {
  async onInit() {
    this.log('SolarControllerDriver init');
  }

  /**
   * System pairing (list_devices/add_devices)
   *
   * Multi-device safe:
   * each pairing attempt gets its own unique Homey device id,
   * so multiple ESP based Solar Controllers can be added.
   *
   * The actual physical unit is then linked by the user through
   * the Host setting in the device settings.
   */
  async onPairListDevices() {
    const baseSettings = {
      host: '',
      performance_mode: 'auto',
      show_advanced: false,
      poll_interval: 5,
      adaptive_polling: false,
      poll_active_interval: 10,
      poll_idle_interval: 30,
      enable_heat_compare_poll: true,
      heat_compare_interval: 60,
      update_only_on_change: true,
      threshold_power_w: 5,
      threshold_pwm_pct: 1,
      threshold_temp_c: 0.1,
      threshold_price: 0.001,
      trigger_debounce_ms: 250,
      trigger_min_interval_s: 2,
      max_concurrent_requests: 2,
      timeout_ms: 2500,
      enable_extra_temps: true,
      debug_logging: false,
      pwm_set_endpoint: '/api/pwm',
    };

    const id = createPairingId();
    const shortId = id.split('_').slice(-1)[0];

    return [{
      name: `Solar Controller ${shortId}`,
      data: { id },
      // Keep capability list in sync with driver.compose.json / app.json.
      capabilities: [
        'measure_power',
        'measure_temperature',
        'sc_pwm',
        'sc_force_heat',
        'sc_relay_manual_on',
        'sc_sun_mode',
        'sc_max_out_pct_control',
        'sc_legionella_manual',
        'sc_legionella_active',
        'sc_max_out_pct',
        'sc_control_mode',
        'sc_legionella_status',
        'sc_mc_role',
        'sc_mc_fallback_active',
        'sc_mc_group_pwm',
        'sc_mc_peers_online',
        'sc_mc_peers_healthy',
        'sc_mc_tcp_realtime',
        'sc_temp_gate_blocked',
        'measure_temperature.2',
        'measure_temperature.3',
        'measure_temperature.4',
      ],
      settings: baseSettings,
    }];
  }
}

module.exports = SolarControllerDriver;
