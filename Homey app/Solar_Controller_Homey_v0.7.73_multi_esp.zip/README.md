# Solar Controller - Homey App (SDK3) v0.7.73

## What Changed

- Multi-ESP support remains: each Solar Controller is a separate Homey device with its own Host setting.
- The device overview keeps useful status tiles, including PWM, max PWM limit, control mode, sun schedule, relay state and Legionella status.
- Firmware version is stored internally for diagnostics, but is not shown as a Homey tile.
- The control page has direct controls for Force heat, manual relay, sun schedule, max PWM controller and Legionella on/off.
- Flow actions are available for sun schedule mode, relay on/off, max PWM, PWM fallback, and Legionella run/cancel.
- Newer firmware without `/api/pwm` is supported through max-output + Force Heat emulation, while older firmware can still use the legacy PWM endpoint.

## Install

```bash
npm install
npm run sync
homey login
homey app install
```

## Source Structure

- `package.json` is the version source.
- `.homeycompose/capabilities` and `.homeycompose/flow` are the Homey capability and flow-card sources.
- `drivers/solar_controller/driver.compose.json` is the driver source.
- `npm run sync` regenerates `app.json`, `.homeycompose/app.json`, `drivers/solar_controller/driver.json` and `drivers/solar_controller/settings.json`.

## Device Settings

- Host: IP address or hostname, for example `192.168.1.215` or `boiler.local`.
- PWM endpoint: default `/api/pwm` for older firmware. Newer firmware can use the built-in fallback.
- Performance mode: use `legacy` for older Homey hardware or when reducing polling load matters.

## Compatibility

Existing paired devices do not need to be paired again. New capabilities and option migrations are applied when the app starts.

## License

GPL-3.0
