# ☀️ Solar Controller – Homey App

Deze Homey-app integreert de **Solar Controller** met Homey.  
De Solar Controller is een lokale controller die zonne-overschot slim benut, onder andere door PWM-aansturing van een elektrische boiler.

👉 De **Solar Controller blijft altijd het regelbrein**.  
👉 Homey is een **optionele integratie** voor inzicht en flows.

---

## ✨ Functionaliteit

Met deze app krijg je in Homey:

- Realtime status en metingen van de Solar Controller
- Inzicht in:
  - PWM-sturing
  - Vermogen (W)
  - Temperaturen (°C)
  - Actuele stroomprijs
  - Actuele / dag-gasprijs
  - Adviesstatus (elektra of gas)
- Uitgebreide Homey **flows**:
  - **Triggers** (status- en adviesveranderingen)
  - **Condities** (prijzen, advies, status)
  - **Acties** (o.a. PWM instellen, schakelen)

Alle beslislogica draait lokaal in de Solar Controller zelf.

---

## 🔁 Architectuur & ontwerp

- Lokale HTTP-API communicatie
- Polling met:
  - overlap-beveiliging
  - timeouts
  - automatische herstart bij tijdelijke fouten
- Geen cloud-afhankelijkheid
- Robuust bij:
  - WiFi herstart
  - controller reboot
  - tijdelijke netwerkuitval

De app is opgezet met stabiliteit en voorspelbaar gedrag als uitgangspunt.

---

## 🔌 Installatie (development / CLI)

Deze app wordt geïnstalleerd via de Homey CLI.

1. Clone of download deze repository
2. Ga naar de app-map
3. Installeer de app:
   ```bash
   homey app install
   ```
4. Open Homey → Apparaten → Voeg **Solar Controller** toe
5. Configureer het IP-adres van de Solar Controller

Na installatie verschijnen de beschikbare metingen en flow-kaarten automatisch.

---

## ⚠️ Belangrijke opmerkingen

- Dit is een **development app** (CLI-installatie)
- Niet gepubliceerd in de Homey App Store
- Gericht op:
  - functionaliteit
  - stabiliteit
  - transparantie
- UI is bewust functioneel gehouden
- Feedback en verbeteringen zijn welkom  
  (graag klein en gericht)

---

## 📦 Versie-informatie

- Huidige versie: **v0.7.60**
- Status: **Development**
- Versies worden actief doorontwikkeld

---

## 🧠 Filosofie

- Lokaal eerst
- Geen cloud lock-in
- Inzicht boven automatisme
- Homey als uitbreiding, niet als afhankelijkheid

De Solar Controller blijft zelfstandig functioneren, ook zonder Homey.
