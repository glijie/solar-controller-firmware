'use strict';
const Homey = require('homey');

class SolarControllerDriver extends Homey.Driver {
  async onInit() {
    this.log('SolarControllerDriver init');
  }

  /**
   * System pairing (list_devices/add_devices)
   *
   * We deliberately expose **one** device during pairing.
   *
   * Homey lets the user pick the tile value via: Device settings → Status indicator.
   */
  async onPairListDevices() {
    const baseSettings = { host: '', poll_interval: 5, timeout_ms: 5000, pwm_set_endpoint: '/api/pwm' };

    // IMPORTANT:
    // The Solar Controller is a single physical unit.
    // Using a random id here allows users to add infinite duplicates.
    // We therefore expose ONE stable device id.
    const id = 'solar_controller';

    return [{
      name: 'Solar Controller',
      data: { id },
      // Keep capability list in sync with driver.compose.json.
      capabilities: ['measure_power','measure_temperature','sc_pwm','sc_max_out_pct','sc_force_heat','measure_temperature.2','measure_temperature.3','measure_temperature.4'],
      settings: baseSettings,
    }];
  }
}

module.exports = SolarControllerDriver;
