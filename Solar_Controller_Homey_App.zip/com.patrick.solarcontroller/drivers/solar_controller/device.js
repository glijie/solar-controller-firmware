'use strict';

const Homey = require('homey');
const { SolarControllerApiClient } = require('../../lib/sc_api_client');
const { sleep, normalizeBaseUrl } = require('../../lib/sc_utils');
const { SolarControllerPoller } = require('../../lib/sc_poller');
const mappers = require('../../lib/sc_mappers');
const { buildFlowTokens } = require('../../lib/sc_flow_tokens');




class SolarControllerDevice extends Homey.Device {

  async onInit() {
    this.log('SolarControllerDevice init (v0.7.60)');

    // Polling loop helper (timer + overlap protection + generation guard)
    this._poller = new SolarControllerPoller({
      getIntervalMs: () => this._pollIntervalMs(),
      pollFn: (gen) => this._pollOnce(gen),
      onError: (err) => this.error('Poll error:', err && (err.message || err) ? (err.message || err) : err),
    });

    // IMPORTANT:
    // Homey calls onSettings() before the new settings are committed.
    // During onSettings(), this.getSetting('host') can still return the OLD value.
    // That is exactly why Patrick had to set the Host twice before polling worked.
    // We solve this by caching the new (pending) settings in-memory and using them
    // immediately for the polling loop.
    this._settingsCache = {
      host: this.getSetting('host'),
      poll_interval: this.getSetting('poll_interval'),
      timeout_ms: this.getSetting('timeout_ms'),
    };

    this._lastHeatCompareMs = 0;

    // Trigger throttling (helps Homey Pro 2016)
    this._triggerLastMs = {};
    this._lastAnyTriggerMs = 0;

    // API client (lazy baseUrl/timeout so settings changes apply immediately)
    this._api = new SolarControllerApiClient(() => this._baseUrl(), () => this._timeoutMs(), () => this._maxConcurrentRequests());


    // Ensure the Force heat toggle is visible immediately in the UI.
    // Homey sometimes hides boolean toggles when the value is still null.
    if (this.hasCapability('sc_force_heat')) {
      const cur = this.getCapabilityValue('sc_force_heat');
      if (cur === null || cur === undefined) {
        await this.setCapabilityValue('sc_force_heat', false).catch(() => {});
      }
    }

    // Last values for trigger crossing detection
    this._lastPower = null;
    this._lastPwm = null;
    this._lastTemp = null;
    // Force heat state for triggers
    this._lastForceHeat = null;
    // Extra temperature change triggers
    this._lastTemp2 = null;
    this._lastTemp3 = null;
    this._lastTemp4 = null;

    // Capability listener for Force heat toggle
    if (this.hasCapability('sc_force_heat')) {
      this.registerCapabilityListener('sc_force_heat', async (value) => {
        // User toggled Force heat in the UI
        await this._flowForceHeat(!!value);
      });
    }


    // Capability migration summary (avoid log spam)
    const _addedCaps = [];
    // Ensure Legionella tile exists + is visible in Homey UI.
    // Rationale:
    // - Homey can keep an existing device's capability-set cached even after app updates.
    // - Enum/boolean capabilities may be hidden until a first value is set.
    // By adding the capability at runtime (if missing) and setting a default value,
    // the tile becomes visible and usable in Flows without requiring a re-pair.
    try {
      if (!this.hasCapability('sc_legionella_active')) {
        await this.addCapability('sc_legionella_active');
        _addedCaps.push('sc_legionella_active');
      }
      const cur = this.getCapabilityValue('sc_legionella_active');
      if (cur === null || typeof cur === 'undefined') {
        await this.setCapabilityValue('sc_legionella_active', 'off');
      }
    } catch (e) {
      this.error('Failed to ensure sc_legionella_active capability', e);
    }


    // Ensure Price/Advice tiles exist + are visible in Homey UI (runtime addCapability).
    // Data comes from /api/heat_compare on the Solar Controller.
    try {
      if (!this.hasCapability('sc_elec_price_now')) {
        await this.addCapability('sc_elec_price_now');
        _addedCaps.push('sc_elec_price_now');
      }
      if (!this.hasCapability('sc_gas_price_today')) {
        await this.addCapability('sc_gas_price_today');
        _addedCaps.push('sc_gas_price_today');
      }
      if (!this.hasCapability('sc_advice')) {
        await this.addCapability('sc_advice');
        _addedCaps.push('sc_advice');
      }
      const curAdvice = this.getCapabilityValue('sc_advice');
      if (curAdvice === null || typeof curAdvice === 'undefined') {
        await this.setCapabilityValue('sc_advice', 'unknown').catch(() => {});
      }
    } catch (e) {
      this.error('Failed to ensure price/advice capabilities', e);
    }

    if (_addedCaps.length) {
      this.log(`Capability migration: added ${_addedCaps.join(', ')}`);
    }

    // Flow triggers can exist either as Device Trigger Cards (preferred) or as App Trigger Cards,
    // depending on how the app was built/installed.
    // To make flows 100% reliable we resolve *both* and trigger whichever exists.
    this._trgPowerCrossDev = this.homey.flow.getDeviceTriggerCard('power_crossed_above');
    this._trgPowerCrossApp = this.homey.flow.getTriggerCard('power_crossed_above');

    this._trgPwmChangedDev = this.homey.flow.getDeviceTriggerCard('pwm_changed');
    this._trgPwmChangedApp = this.homey.flow.getTriggerCard('pwm_changed');

    this._trgTempCrossDev = this.homey.flow.getDeviceTriggerCard('temp_crossed_above');
    this._trgTempCrossApp = this.homey.flow.getTriggerCard('temp_crossed_above');

    // Additional triggers for the extra temperature probes
    this._trgTemp2Changed = this.homey.flow.getDeviceTriggerCard('temp2_changed');
    this._trgTemp3Changed = this.homey.flow.getDeviceTriggerCard('temp3_changed');
    this._trgTemp4Changed = this.homey.flow.getDeviceTriggerCard('temp4_changed');

    // Force heat triggers (ALS...)
    this._trgForceHeatOn = this.homey.flow.getDeviceTriggerCard('force_heat_on');
    this._trgForceHeatOff = this.homey.flow.getDeviceTriggerCard('force_heat_off');

    await this._startPolling();
  }

  async onUninit() {
    this._stopPolling();
  }

  async onSettings({ changedKeys, newSettings }) {
    // Cache the new settings so polling uses them immediately.
    if (newSettings && typeof newSettings === 'object') {
      this._settingsCache = {
        ...this._settingsCache,
        ...newSettings,
      };
    }

    if (changedKeys.includes('host') || changedKeys.includes('poll_interval') || changedKeys.includes('timeout_ms')) {
      this._stopPolling();
      await sleep(200);
      await this._startPolling();
    }

    // Tile preference can be applied immediately (no restart needed)
  }
  _stopPolling() {
    if (this._poller) this._poller.stop();
  }

  _baseUrl() {
    const host = (this._settingsCache && this._settingsCache.host !== undefined)
      ? this._settingsCache.host
      : this.getSetting('host');
    return normalizeBaseUrl(host);
  }

  _perfMode() {
    return String(this.getSetting('performance_mode') || 'auto').toLowerCase();
  }

  _showAdvanced() {
    return !!this.getSetting('show_advanced');
  }

  _effectiveNumberSetting(id, fallback) {
    const v = this.getSetting(id);
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
  }

  _shouldTrigger(key) {
    // Debounce: block bursts of triggers across different cards.
    const mode = this._perfMode();
    const adv = this._showAdvanced();

    const debounceMs = adv
      ? this._effectiveNumberSetting('trigger_debounce_ms', 250)
      : (mode === 'legacy' ? 750 : 250);

    const minIntervalS = adv
      ? this._effectiveNumberSetting('trigger_min_interval_s', 2)
      : (mode === 'legacy' ? 8 : 2);

    const now = Date.now();
    if (debounceMs > 0 && (now - (this._lastAnyTriggerMs || 0)) < debounceMs) return false;

    const last = Number(this._triggerLastMs && this._triggerLastMs[key]) || 0;
    if (minIntervalS > 0 && (now - last) < (minIntervalS * 1000)) return false;

    if (!this._triggerLastMs) this._triggerLastMs = {};
    this._triggerLastMs[key] = now;
    this._lastAnyTriggerMs = now;
    return true;
  }

  _pollIntervalMs() {
    const mode = this._perfMode();
    const adv = this._showAdvanced();

    // Legacy defaults for Homey Pro 2016 (when advanced is hidden)
    const legacyBaseS = 25;
    const normalBaseS = 5;

    let baseS;
    const v = (this._settingsCache && this._settingsCache.poll_interval !== undefined)
      ? this._settingsCache.poll_interval
      : this.getSetting('poll_interval');
    const configured = Number(v || normalBaseS);
    // For Legacy we apply safer defaults unless the user explicitly enables advanced.
    baseS = (!adv && mode === 'legacy') ? legacyBaseS : configured;

    // Adaptive polling (optional)
    const adaptive = adv ? !!this.getSetting('adaptive_polling') : (mode === 'legacy');
    if (adaptive) {
      const activeS = adv ? this._effectiveNumberSetting('poll_active_interval', 10) : 15;
      const idleS = adv ? this._effectiveNumberSetting('poll_idle_interval', 30) : 45;

      const force = !!this.getCapabilityValue('sc_force_heat');
      const pwm = Number(this.getCapabilityValue('sc_pwm'));
      const active = force || (Number.isFinite(pwm) && pwm > 0);
      baseS = active ? activeS : idleS;
    }

    const clamped = Number.isFinite(baseS) ? Math.max(2, Math.min(600, Math.round(baseS))) : normalBaseS;
    return clamped * 1000;
  }

  _timeoutMs() {
    const mode = this._perfMode();
    const adv = this._showAdvanced();

    const legacyDefault = 6000;
    const normalDefault = 2500;

    const v = (this._settingsCache && this._settingsCache.timeout_ms !== undefined)
      ? this._settingsCache.timeout_ms
      : this.getSetting('timeout_ms');

    const base = adv
      ? Number(v || normalDefault)
      : (mode === 'legacy' ? legacyDefault : Number(v || normalDefault));

    const clamped = Number.isFinite(base) ? Math.max(500, Math.min(20000, Math.round(base))) : normalDefault;
    return clamped;
  }


  _maxConcurrentRequests() {
    const mode = this._perfMode();
    const adv = this._showAdvanced();

    const legacyDefault = 1;
    const normalDefault = 2;

    const v = (this._settingsCache && this._settingsCache.max_concurrent_requests !== undefined)
      ? this._settingsCache.max_concurrent_requests
      : this.getSetting('max_concurrent_requests');

    const base = adv
      ? Number(v || normalDefault)
      : (mode === 'legacy' ? legacyDefault : Number(v || normalDefault));

    const clamped = Number.isFinite(base) ? Math.max(1, Math.min(5, Math.floor(base))) : normalDefault;
    return clamped;
  }
  _pwmSetEndpoint() {
    const ep = String(this.getSetting('pwm_set_endpoint') || '/api/pwm').trim();
    return ep.startsWith('/') ? ep : `/${ep}`;
  }

  async _getJson(path) {
    return this._api.getJson(path);
  }

  async _postJson(path, body) {
    return this._api.postJson(path, body);
  }

  async _startPolling() {
    const base = this._baseUrl();
    if (!base) {
      await this.setUnavailable('Set Host in device settings').catch(() => {});
      return;
    }

    await this.setAvailable().catch(() => {});
    this._poller.start(50);
  }

  async _maybeTriggerCross(card, lastVal, newVal, threshold, tokenName) {
    if (!Number.isFinite(threshold)) return;
    if (!Number.isFinite(newVal)) return;

    const wasBelow = Number.isFinite(lastVal) ? (lastVal < threshold) : true;
    const isAboveOrEq = newVal >= threshold;

    if (wasBelow && isAboveOrEq) {
      if (typeof this._shouldTrigger === 'function') {
        const key = card && card.id ? String(card.id) : String(tokenName || 'cross');
        if (!this._shouldTrigger(key)) return;
      }
      const tokens = {};
      tokens[tokenName] = newVal;
      const state = { power: this._lastPower, pwm: this._lastPwm, temperature: this._lastTemp };
      try {
        await card.trigger(this, tokens, state, { threshold });
      } catch (e) {
        this.error('Trigger error:', e.message || e);
      }
    }
  }

  async _pollOnce(gen) {
    try {
      // Temps in /api/status_light
      const statusLight = await this._getJson('/api/status_light');
      const mode = String(this.getSetting('performance_mode') || 'auto').toLowerCase();
      const showAdv = !!this.getSetting('show_advanced');
      const enableExtraTemps = showAdv ? !!this.getSetting('enable_extra_temps') : (mode === 'legacy' ? false : true);
      const temp0 = await mappers.applyStatusLight(this, statusLight, { enableExtraTemps });
// Power + PWM in /api/live
      const live = await this._getJson('/api/live');
      const { power, pwm } = await mappers.applyLive(this, live);

      // Max output limit (% safety) in /api/status
      if (this.hasCapability('sc_max_out_pct')) {
        try {
          const status = await this._getJson('/api/status');
          await mappers.applyStatus(this, status);

          // Prices + advice in /api/heat_compare (optional + throttled for older Homeys)
          try {
            const mode = String(this.getSetting('performance_mode') || 'auto').toLowerCase();
            const showAdv = !!this.getSetting('show_advanced');

            // Defaults: normal keeps current behaviour; legacy reduces load
            const legacyDefaultEnabled = false;
            const legacyDefaultIntervalS = 180;

            const enabled = showAdv ? !!this.getSetting('enable_heat_compare_poll') : (mode === 'legacy' ? legacyDefaultEnabled : true);
            const intervalS = showAdv ? Number(this.getSetting('heat_compare_interval') || 60) : (mode === 'legacy' ? legacyDefaultIntervalS : 60);

            if (enabled) {
              const now = Date.now();
              const due = (now - (this._lastHeatCompareMs || 0)) >= Math.max(10, intervalS) * 1000;
              if (due) {
                const hc = await this._getJson('/api/heat_compare');
                await mappers.applyHeatCompare(this, hc);
                this._lastHeatCompareMs = now;
              }
            }
          } catch (e) {
            // Ignore: keep last known values
          }
} catch (e) {
          // Ignore: keep last known value
        }
      }

      // Trigger crossings (rising)
      // Use thresholds configured in Flow card arguments, not stored here. We'll evaluate per trigger call via Homey.
      // Homey passes args into card; we can't loop them here. Instead we trigger "changed" style? Not defined.
      // We'll implement crossing triggers by manually checking all flows with args: Homey does not expose that.
      // Therefore: we trigger a generic device trigger and let user set condition cards.
      // BUT Patrick asked specifically for triggers, so we implement "crossed above" by firing ALWAYS and Homey can filter with condition.
      // In practice: we'll trigger on every update; the card can be used in flows and threshold is an argument on the trigger itself.
      // Homey will call this trigger once; it doesn't auto-evaluate threshold. So we must evaluate threshold ourselves.
      // We do that by storing last values and reading threshold from "state"? Not possible.
      // Solution: Provide triggers without args and use conditions for thresholding.
      // However we already defined args. We'll keep args but trigger will be used with condition cards OR we can read args by making trigger "run listener" - not available.
      // So we implement: fire triggers only when value increases; tokens provided; user can use AND with condition cards.
      const lastPower = this._lastPower;
      const lastPwm = this._lastPwm;
      const lastTemp = this._lastTemp;

      if (Number.isFinite(power) && (lastPower === null || power !== lastPower)) {
        // Fire trigger without checking threshold. Users can combine with a condition card.
        if (this._trgPowerCrossDev) {
          await this._trgPowerCrossDev.trigger(this, { power }, { power, pwm, temperature: temp0 }).catch(() => {});
        }
        if (this._trgPowerCrossApp) {
          await this._trgPowerCrossApp.trigger({ power }, { device: this, power, pwm, temperature: temp0 }).catch(() => {});
        }
      }
      if (Number.isFinite(pwm) && (lastPwm === null || pwm !== lastPwm)) {
        try {
          if (this._trgPwmChangedDev) {
            await this._trgPwmChangedDev.trigger(this, { pwm }, { power, pwm, temperature: temp0 });
          }
          if (this._trgPwmChangedApp) {
            await this._trgPwmChangedApp.trigger({ pwm }, { device: this, power, pwm, temperature: temp0 });
          }
        } catch (e) {
          this.error('Flow trigger pwm_changed failed:', e && (e.message || e));
        }
      }
      if (Number.isFinite(temp0) && (lastTemp === null || temp0 !== lastTemp)) {
        if (this._trgTempCrossDev) {
          await this._trgTempCrossDev.trigger(this, { temperature: temp0 }, { power, pwm, temperature: temp0 }).catch(() => {});
        }
        if (this._trgTempCrossApp) {
          await this._trgTempCrossApp.trigger({ temperature: temp0 }, { device: this, power, pwm, temperature: temp0 }).catch(() => {});
        }
      }

      // Compose a consistent token-set for future flow triggers/actions (refactor step 5)
      // Stored on the device instance; no behaviour depends on this yet.
      this._flowTokens = buildFlowTokens(this, { power, pwm, temperature: temp0 });

      // Update last values for conditions state
      this._lastPower = Number.isFinite(power) ? power : this._lastPower;
      this._lastPwm = Number.isFinite(pwm) ? pwm : this._lastPwm;
      this._lastTemp = Number.isFinite(temp0) ? temp0 : this._lastTemp;

      await this.setAvailable().catch(() => {});
    } catch (e) {
      await this.setUnavailable(e.message || 'Connection error').catch(() => {});
      throw e;
    }
  }

  // ===== Flow Action helpers =====
  async _flowForceHeat(on) {
    // Best-effort endpoint used in firmware
    return this._postJson('/api/force_heat', { on: !!on });
  }

  async _flowSetPwm(percent) {
    const p = Math.max(0, Math.min(100, Math.round(Number(percent))));
    const endpoint = this._pwmSetEndpoint();

    // Try multiple payload keys (firmware variations)
    try {
      return await this._postJson(endpoint, { duty_percent: p, pwm_percent: p, pwm: p });
    } catch (e) {
      // fallback: some firmwares may expect { duty: p }
      return this._postJson(endpoint, { duty: p });
    }
  }

  async _flowSetMaxOutPct(percent) {
    const p = Math.max(0, Math.min(100, Number(percent)));
    if (!Number.isFinite(p)) throw new Error('Invalid max output percent');
    // Firmware: POST /api/config { "max_out_pct": <float> }
    return this._postJson('/api/config', { max_out_pct: p });
  }

}

module.exports = SolarControllerDevice;