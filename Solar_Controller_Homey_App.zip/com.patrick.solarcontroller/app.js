'use strict';

const Homey = require('homey');

class SolarControllerApp extends Homey.App {

  async onInit() {
    this.log('Solar Controller app started (v0.7.40)');

    // Flow Cards (v0.7.5)
    // - Conditions & Actions include a required Device argument, so the user selects which Solar Controller.
    // - Triggers are Device Triggers (they already know which device fired).
    const condPowerAbove = this.homey.flow.getConditionCard('power_above');
    const condPwmAbove = this.homey.flow.getConditionCard('pwm_above');
    const condTempAbove = this.homey.flow.getConditionCard('temp_above');
    const condLegActive = this.homey.flow.getConditionCard('legionella_is_active');

        const condAdviceIs = this.homey.flow.getConditionCard('advice_is');
    const condElecBelow = this.homey.flow.getConditionCard('elec_price_below');
    const condGasBelow = this.homey.flow.getConditionCard('gas_price_below');

const actForceOn = this.homey.flow.getActionCard('force_heat_on');
    const actForceOff = this.homey.flow.getActionCard('force_heat_off');
    const actSetPwm = this.homey.flow.getActionCard('set_pwm_percent');
    const actSetMaxOut = this.homey.flow.getActionCard('set_max_output_pct');

    // Conditions: read current capability values from the selected device
    condPowerAbove.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const power = Number(args.device.getCapabilityValue('measure_power'));
      if (!Number.isFinite(threshold) || !Number.isFinite(power)) return false;
      return power > threshold;
    });

    condPwmAbove.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const pwmPercent = Number(args.device.getCapabilityValue('sc_pwm'));
      if (!Number.isFinite(threshold) || !Number.isFinite(pwmPercent)) return false;
      return pwmPercent > threshold;
    });

    condTempAbove.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const temperature = Number(args.device.getCapabilityValue('measure_temperature'));
      if (!Number.isFinite(threshold) || !Number.isFinite(temperature)) return false;
      return temperature > threshold;
    });

    // Condition: Legionella active
    condLegActive.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const v = args.device.getCapabilityValue('sc_legionella_active');
      return v === 'on' || v === true || v === 1;
    });

    // Condition: Heating advice equals selected option
    condAdviceIs.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const want = String(args.advice || 'unknown');
      const cur = String(args.device.getCapabilityValue('sc_advice') || 'unknown');
      return cur === want;
    });

    // Condition: Electricity price below threshold (€/kWh)
    condElecBelow.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const v = Number(args.device.getCapabilityValue('sc_elec_price_now'));
      if (!Number.isFinite(threshold) || !Number.isFinite(v)) return false;
      return v < threshold;
    });

    // Condition: Gas price below threshold (€/m³)
    condGasBelow.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const threshold = Number(args.threshold);
      const v = Number(args.device.getCapabilityValue('sc_gas_price_today'));
      if (!Number.isFinite(threshold) || !Number.isFinite(v)) return false;
      return v < threshold;
    });


    // Actions: call device helpers (POST to controller)
    actForceOn.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowForceHeat(true);
    });

    actForceOff.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      return args.device._flowForceHeat(false);
    });

    actSetPwm.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const percent = Number(args.percent);
      if (!Number.isFinite(percent)) throw new Error('Invalid PWM percent');
      return args.device._flowSetPwm(percent);
    });

    actSetMaxOut.registerRunListener(async (args) => {
      if (!args || !args.device) throw new Error('No device selected');
      const percent = Number(args.percent);
      if (!Number.isFinite(percent)) throw new Error('Invalid max output percent');
      return args.device._flowSetMaxOutPct(percent);
    });
  }

}

module.exports = SolarControllerApp;
