# Solar Controller — Homey App (SDK3) v0.7.0

## Fix in v0.7.0 (your “first connect only works after changing host” issue)
Homey can miss the very first HTTP call due to **mDNS/ARP warm-up**.
This version fixes it by:
- Doing a **warm-up burst** (3 tries with backoff) after changing Host or on startup
- Only going offline after **3 consecutive** failures (instead of 1)

## Install permanently (no terminal needed afterwards)
```bash
npm install
homey login
homey app install
```

## Device settings
- Host: IP/hostname (e.g. 192.168.1.215 or boiler.local)
- PWM endpoint (advanced): default `/api/pwm` (sends `{ "pct": 0..100 }`)


## License
GPL-3.0


## Changelog

- **0.7.45** – Refactor: added central flow token builder (no functional changes)

- v0.7.0: Branding update (new icon.svg + images).

- v0.7.0: Fix PWM 404 by endpoint fallback + label PWM slider.


## v0.7.41
- Refactor: split shared helpers into /lib (no functional changes)
